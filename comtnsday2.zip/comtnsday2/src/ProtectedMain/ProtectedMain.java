package ProtectedMain;
import ProtectedNormal.*;
public class ProtectedMain extends ProtectedNormal 
{

	public static void main(String[] args) 
	{
		ProtectedMain n2 = new ProtectedMain();
		System.out.println(n2.str);
	
	}

}


